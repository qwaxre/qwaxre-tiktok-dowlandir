# SaveTok

## Download tiktok videos in hd and without watermark.

Check the live [demo](https://savetok.vercel.app).

## Features

- Save video history

## Run locally

Clone the repo and run:

### `npm install`

### `npm start`
